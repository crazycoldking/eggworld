import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _2d01cf87 = () => import('..\\pages\\bounty.vue' /* webpackChunkName: "pages_bounty" */).then(m => m.default || m)
const _3ba0158f = () => import('..\\pages\\foundation.vue' /* webpackChunkName: "pages_foundation" */).then(m => m.default || m)
const _bd732fb4 = () => import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */).then(m => m.default || m)
const _35f7fe7e = () => import('..\\pages\\_LANG\\index.vue' /* webpackChunkName: "pages__LANG_index" */).then(m => m.default || m)
const _2f20a5d4 = () => import('..\\pages\\_LANG\\foundation.vue' /* webpackChunkName: "pages__LANG_foundation" */).then(m => m.default || m)
const _60f74a4c = () => import('..\\pages\\_LANG\\bounty.vue' /* webpackChunkName: "pages__LANG_bounty" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/bounty",
			component: _2d01cf87,
			name: "bounty"
		},
		{
			path: "/foundation",
			component: _3ba0158f,
			name: "foundation"
		},
		{
			path: "/",
			component: _bd732fb4,
			name: "index"
		},
		{
			path: "/:LANG",
			component: _35f7fe7e,
			name: "LANG"
		},
		{
			path: "/:LANG/foundation",
			component: _2f20a5d4,
			name: "LANG-foundation"
		},
		{
			path: "/:LANG/bounty",
			component: _60f74a4c,
			name: "LANG-bounty"
		}
    ],
    
    
    fallback: false
  })
}
