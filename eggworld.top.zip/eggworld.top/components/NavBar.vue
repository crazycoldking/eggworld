<template>
    <b-navbar class="nav-top fluid" toggleable="md" sticky>
        <div class="container">
            <b-navbar-brand :href="logoRedirect($i18n.locale)"><img class="logo not-animate" src="/eggworld.top.png" alt="GXChain">
            </b-navbar-brand>
            <b-navbar-toggle target="nav_collapse"></b-navbar-toggle>
            <b-collapse is-nav id="nav_collapse">
                <b-navbar-nav class="ml-auto">
                    <b-nav-item v-for="(item,index) in navList" :key="index" :target="item.target" :class="{'active':navActive(item.name)}">
                        {{$t('links.'+item.name)}}
                    </b-nav-item>
                </b-navbar-nav>
            </b-collapse>
        </div>
    </b-navbar>
</template>
<script>
export default {
    data () {
        return {
            navList: [
                {
                    name: "bounty",
                    path: {
                        zh: "/bounty",
                        en: "/en/bounty"
                    },
                    target: "_self"
                },
                {
                    name: "resource",
                    path: {
                        zh: "/resource",
                        en: "/en/resource"
                    },
                    target: "_self"
                },
                {
                    name: "foundation",
                    path: {
                        zh: "/foundation",
                        en: "/en/foundation"
                    },
                    target: "_self"
                }
              
            ]
        };
    },
    methods: {
        navActive (navName) {
            return this.$route.fullPath.indexOf(navName) != -1;
        },
        switchLanguage (locale) {
            if (this._i18n.locale === "zh") {
                if (locale === "en") {
                    this.$router.push(`/en${this.$route.fullPath}`);
                }
            } else {
                if (locale === "zh") {
                    this.$router.push(`${this.$route.fullPath.replace(/^\/[^\/]+/, "")}`);
                }
            }
        },
        logoRedirect (locale) {
            let _href;
            switch (locale) {
                case "zh":
                    _href = "/";
                    break;
                case "en":
                    _href = "/en/";
                    break;
            }
            return _href;
        }
    }
};
</script>
<style scoped>
.nav-top {
  border-bottom: 1px solid #e5e9ef;
  background: #fff;
}

.logo {
  height: 1.6rem;
}

.navbar {
  color: #666666;
}

.navbar-nav li {
  margin-left: 0.5rem;
  margin-right: 0.5rem;
}

.navbar-nav li .nav-link {
  padding-left: 0 !important;
  padding-right: 0 !important;
}

.navbar-nav li.active {
  border-bottom: 2px solid #6699ff;
}

.flag-img {
  width: 20px;
  margin-right: 10px;
}

@media (min-width: 768px) {
  .navbar {
    height: 80px;
  }
}

@media (max-width: 768px) {
  .navbar-nav li {
    text-align: center;
    font-size: 14px;
  }

  .navbar-nav li.active {
    border-bottom: none;
  }
}
</style>
